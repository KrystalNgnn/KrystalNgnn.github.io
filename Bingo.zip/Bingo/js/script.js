


function doubleClick(){
	document.getElementById('item').style.backgroundColor="red";
}
